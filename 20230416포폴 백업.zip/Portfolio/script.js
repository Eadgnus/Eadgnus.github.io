// function openClose() {
//     if(document.getElementById('navbar__menu').style.display ===     'block') {
//         document.getElementById('navbar__menu').style.display = 'none';
//     } else {
//         document.getElementById('navbar__menu').style.display = 'block';
//     }
// }


// 실행했을 때 아이디로 요소를 가져와서 style에 display가 block 이라면
// none으로 바꿔준다 
// 아니면 block으로 바꿔준다.


/* 토글버튼 시작 */
const btn = document.getElementById('navbar__toggle-btn'); // 토글버튼의 아이디로 요소를 선택
const box = document.getElementById('navbar__menu'); // 동일

btn.addEventListener('click', () => { 
    //btn에 이벤트 리스너를 add하는 addEventListener를 사용하여 click속성을주고화살표함수로 
    //메뉴에 클래스리스트 토글로 act Css를 on off함
    box.classList.toggle('act');
  })
  /* 토글버튼 끝  */

// const navbar__menu1 = document.getElementById('navbar__menu1');
// const navbar__menu2 = document.getElementById('navbar__menu2');
// const navbar__menu3 = document.getElementById('navbar__menu3');
// const navbar__menu4 = document.getElementById('navbar__menu4');
// const navbar__menu5 = document.getElementById('navbar__menu5');
// const navbar__menu6 = document.getElementById('navbar__menu6');

// navbar__menu1.addEventListener('click', () => {
//     navbar__menu1.classList.add('active');
//     navbar__menu2.classList.remove('active');
//     navbar__menu3.classList.remove('active');
//     navbar__menu4.classList.remove('active');
//     navbar__menu5.classList.remove('active');
//     navbar__menu6.classList.remove('active');
// });
// navbar__menu2.addEventListener('click', () => {
//     navbar__menu2.classList.add('active');
//     navbar__menu1.classList.remove('active');
//     navbar__menu3.classList.remove('active');
//     navbar__menu4.classList.remove('active');
//     navbar__menu5.classList.remove('active');
//     navbar__menu6.classList.remove('active');
// });
// navbar__menu3.addEventListener('click', () => {
//     navbar__menu3.classList.add('active');
//     navbar__menu1.classList.remove('active');
//     navbar__menu2.classList.remove('active');
//     navbar__menu4.classList.remove('active');
//     navbar__menu5.classList.remove('active');
//     navbar__menu6.classList.remove('active');
// });
// navbar__menu4.addEventListener('click', () => {
//     navbar__menu4.classList.add('active');
//     navbar__menu1.classList.remove('active');
//     navbar__menu3.classList.remove('active');
//     navbar__menu2.classList.remove('active');
//     navbar__menu5.classList.remove('active');
//     navbar__menu6.classList.remove('active');
// });
// navbar__menu5.addEventListener('click', () => {
//     navbar__menu5.classList.add('active');
//     navbar__menu1.classList.remove('active');
//     navbar__menu3.classList.remove('active');
//     navbar__menu4.classList.remove('active');
//     navbar__menu2.classList.remove('active');
//     navbar__menu6.classList.remove('active');
// });
// navbar__menu6.addEventListener('click', () => {
//     navbar__menu6.classList.add('active');
//     navbar__menu1.classList.remove('active');
//     navbar__menu3.classList.remove('active');
//     navbar__menu4.classList.remove('active');
//     navbar__menu5.classList.remove('active');
//     navbar__menu2.classList.remove('active');
// });


// 메뉴 네비바에서 선택한 메뉴에 테두리 속성 유지시키고 나머지 메뉴에서 삭제하기
const navMenus = document.querySelectorAll('.navbar__menu__item');
navMenus.forEach(menu => {
  menu.addEventListener('click', () => {
    navMenus.forEach(m => m.classList.remove('active'));
    menu.classList.add('active');
  });
});

// 카테고리 버튼에서 위에랑 마찬가지
const category__menu = document.querySelectorAll('.category__btn');
category__menu.forEach(menu => {
    menu.addEventListener('click', () =>{
        category__menu.forEach(m => m.classList.remove('selected'));
        menu.classList.add('selected');
    });
});

const moveNavMenus = document.querySelectorAll('.navbar__menu__item');

moveNavMenus.forEach(menu => {
  menu.addEventListener('click', () => {
    const href = menu.getAttribute('href'); // 클릭된 메뉴의 href 속성을 가져옴
    const offsetTop = document.querySelector(href).offsetTop; // 해당 섹션의 offsetTop 값을 가져옴
    window.scrollTo({ top: offsetTop, behavior: 'smooth' }); // 해당 섹션으로 부드러운 스크롤 이동
  });
});

// window.addEventListener('scroll', () => { 
//     //스크롤을 할 때마다 로그로 현재 스크롤의 위치가 찍혀나온다.
//     console.log(window.scrollX, window.scrollY);
//   });//0 1416